# sample_pac/ab/a.py
def hello():
    print("sample_pac.ab.a모듈의 hello")
if __name__ == "__main__":
    hello()