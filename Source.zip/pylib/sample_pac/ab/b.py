def world():
    print("sample_pac.ac.b모듈의 world")
if __name__ == "__main__":
    world()