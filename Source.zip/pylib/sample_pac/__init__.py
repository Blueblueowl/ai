'''
sample_pac/__init__.py
sample_pac 패키지를 초기화하는 파일
'''
print("sample_pac 패키지를 로드했어요")

def test():
    print("sample_pac안의 test()입니다")